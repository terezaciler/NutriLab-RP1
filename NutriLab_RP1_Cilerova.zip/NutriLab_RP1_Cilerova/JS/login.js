document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    fetch("php/login.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
    })
        .then(response => response.json())
        .then(data => {
            const msg = document.getElementById("loginMessage");
            if (data.success) {
                msg.textContent = "Přihlášení proběhlo úspěšně!";
                // Uložení role do localStorage a přesměrování
                localStorage.setItem("userRole", data.role);
                localStorage.setItem("userEmail", email);
                window.location.href = "dashboard.html";
            }
            else {
                msg.textContent = "Špatné přihlašovací údaje.";
            }
        })
        .catch(err => console.error("Chyba:", err));
});