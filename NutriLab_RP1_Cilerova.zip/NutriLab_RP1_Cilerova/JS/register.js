document.addEventListener("DOMContentLoaded", () => {
    // Skrytí/přepnutí výběru terapeuta
    const roleSelect = document.getElementById("role");
    const therapistWrapper = document.getElementById("therapistSelectWrapper");
    const therapistSelect = document.getElementById("assignedTo");

    roleSelect.addEventListener("change", () => {
        if (roleSelect.value === "klient") {
            therapistWrapper.style.display = "block";

            // Načíst specialisty ze users.json
            fetch("data/users.json")
                .then(res => res.json())
                .then(users => {
                    const specialists = users.filter(u => u.role === "specialista");
                    therapistSelect.innerHTML = specialists.map(s => `
                        <option value="${s.id}">${s.name}</option>
                    `).join("");
                });
        } else {
            therapistWrapper.style.display = "none";
            therapistSelect.innerHTML = "";
        }
    });
});

document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;
    const assignedToElement = document.getElementById("assignedTo");
    const assignedTo = assignedToElement ? assignedToElement.value : null;

    const user = {
        name,
        email,
        password,
        role
    };

    if (role === "klient") {
        if (!assignedTo) {
            alert("Vyberte svého specialistu.");
            return;
        }
        user.assignedTo = parseInt(assignedTo);
        user.program = "free";
        user.plan = {
            breakfast: "Zatím nenastaveno",
            lunch: "Zatím nenastaveno",
            dinner: "Zatím nenastaveno"
        };
    }

    fetch("php/register.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    })
        .then(response => response.json())
        .then(data => {
            const msg = document.getElementById("registerMessage");
            if (data.success) {
                if (msg) msg.textContent = "Registrace proběhla úspěšně!";
                setTimeout(() => {
                    window.location.href = "login.html";
                }, 1500);
            } else {
                if (msg) msg.textContent = data.message || "Registrace selhala.";
            }
        })
        .catch(err => console.error("Chyba:", err));
});
