// Načtení role z localStorage
const role = localStorage.getItem("userRole");
const email = localStorage.getItem("userEmail");
const welcome = document.getElementById("welcomeMessage");
const content = document.getElementById("roleContent");

if (!role || !email) {
    window.location.href = "login.html";
} else {
    welcome.textContent = `Jste přihlášen jako: ${role.toUpperCase()}`;

    switch (role) {
        case "klient":
            fetch("data/users.json")
                .then(res => res.json())
                .then(users => {
                    const userEmail = localStorage.getItem("userEmail");
                    const currentUser = users.find(u => u.email === userEmail);
                    const therapist = users.find(u => u.id === currentUser.assignedTo);

                    content.innerHTML = `
            <h3>Váš plán</h3>
            <p><strong>Program:</strong> ${currentUser.program}</p>
            <ul>
              <li><strong>Snídaně:</strong> ${currentUser.plan.breakfast}</li>
              <li><strong>Oběd:</strong> ${currentUser.plan.lunch}</li>
              <li><strong>Večeře:</strong> ${currentUser.plan.dinner}</li>
            </ul>

            <h3>Váš specialista</h3>
            <p>${therapist.name} (<a href="mailto:${therapist.email}">${therapist.email}</a>)</p>
            <button class="btn" onclick="sendMessageUI(${currentUser.id}, ${therapist.id}, '${therapist.name}')">
              Napsat zprávu
            </button>
          `;

                    fetch("data/messages.json")
                        .then(res => res.json())
                        .then(messages => {
                            const myMessages = messages.filter(m =>
                                (m.from === currentUser.id && m.to === therapist.id) ||
                                (m.from === therapist.id && m.to === currentUser.id)
                            );
                            if (myMessages.length > 0) {
                                content.innerHTML += "<h3>Vaše zprávy:</h3><ul>";
                                myMessages.forEach(msg => {
                                    const direction = msg.from === currentUser.id ? "➡️ odesláno" : "⬅️ přijato";
                                    content.innerHTML += `<li>${direction}: ${msg.message} <em>(${msg.timestamp})</em></li>`;
                                });
                                content.innerHTML += "</ul>";
                            }
                        });
                });
            break;

        case "specialista":
            fetch("data/users.json")
                .then(res => res.json())
                .then(users => {
                    const userEmail = localStorage.getItem("userEmail");
                    const currentUser = users.find(u => u.email === userEmail);

                    const myClients = users.filter(u => u.role === "klient" && u.assignedTo === currentUser.id);

                    if (myClients.length === 0) {
                        content.innerHTML = "<p>Momentálně nemáte přiřazené žádné klienty.</p>";
                        return;
                    }

                    const list = document.createElement("ul");
                    list.innerHTML = myClients.map(client => `
            <li>
              <button class="btn" onclick="showClientDetail(${client.id})">${client.name}</button>
            </li>
          `).join("");

                    content.innerHTML = "<h3>Seznam vašich klientů:</h3>";
                    content.appendChild(list);

                    window.showClientDetail = function(id) {
                        const client = myClients.find(c => c.id === id);
                        content.innerHTML = `
              <h3>Detail klienta: ${client.name}</h3>
              <p><strong>Program:</strong> ${client.program}</p>
              <ul>
                <li><strong>Snídaně:</strong> ${client.plan.breakfast}</li>
                <li><strong>Oběd:</strong> ${client.plan.lunch}</li>
                <li><strong>Večeře:</strong> ${client.plan.dinner}</li>
              </ul>
              <button class="btn" onclick="sendMessageUI(${currentUser.id}, ${client.id}, '${client.name}')">Napsat zprávu</button>
              <br><br>
              <button class="btn" onclick="location.reload()">Zpět na seznam klientů</button>
            `;

                        fetch("data/messages.json")
                            .then(res => res.json())
                            .then(messages => {
                                const myMessages = messages.filter(m =>
                                    (m.from === currentUser.id && m.to === client.id) ||
                                    (m.from === client.id && m.to === currentUser.id)
                                );
                                if (myMessages.length > 0) {
                                    content.innerHTML += "<h3>Vaše zprávy:</h3><ul>";
                                    myMessages.forEach(msg => {
                                        const direction = msg.from === currentUser.id ? "➡️ odesláno" : "⬅️ přijato";
                                        content.innerHTML += `<li>${direction}: ${msg.message} <em>(${msg.timestamp})</em></li>`;
                                    });
                                    content.innerHTML += "</ul>";
                                }
                            });
                    };
                });
            break;

        case "admin":
            content.innerHTML = "<h3>Správa uživatelů</h3>";

            fetch("data/users.json")
                .then(res => res.json())
                .then(users => {
                    const table = document.createElement("table");
                    table.innerHTML = `
            <tr><th>ID</th><th>Jméno</th><th>Email</th><th>Role</th><th>Akce</th></tr>
            ${users.map(user => `
              <tr>
                <td>${user.id}</td>
                <td><input value="${user.name}" data-id="${user.id}" class="name-input"/></td>
                <td>${user.email}</td>
                <td>
                  <select data-id="${user.id}" class="role-select">
                    <option value="klient" ${user.role === "klient" ? "selected" : ""}>Klient</option>
                    <option value="specialista" ${user.role === "specialista" ? "selected" : ""}>Specialista</option>
                    <option value="admin" ${user.role === "admin" ? "selected" : ""}>Admin</option>
                  </select>
                </td>
                <td>
                  <button onclick="updateUser(${user.id})">Upravit</button>
                  <button onclick="deleteUser(${user.id})">Smazat</button>
                </td>
              </tr>
            `).join("")}
          `;
                    content.appendChild(table);
                });
            break;

        default:
            content.innerHTML = "<p>Neznámá role.</p>";
    }
}

function logout() {
    localStorage.removeItem("userRole");
    localStorage.removeItem("userEmail");
    window.location.href = "index.html";
}

function updateUser(id) {
    const name = document.querySelector(`.name-input[data-id='${id}']`).value;
    const role = document.querySelector(`.role-select[data-id='${id}']`).value;

    fetch("php/update.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, name, role })
    }).then(() => alert("Uživatel aktualizován."));
}

function deleteUser(id) {
    if (!confirm("Opravdu smazat uživatele?")) return;

    fetch("php/delete.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
    }).then(() => location.reload());
}

function sendMessageUI(fromId, toId, recipientName) {
    content.innerHTML = `
    <h3>Poslat zprávu: ${recipientName}</h3>
    <textarea id="messageText" rows="5" style="width:100%; max-width:500px;" placeholder="Napište zprávu..."></textarea><br><br>
    <button class="btn" onclick="sendMessage(${fromId}, ${toId})">Odeslat</button>
    <button class="btn" onclick="location.reload()">Zpět</button>
  `;
}

function sendMessage(from, to) {
    const message = document.getElementById("messageText").value;

    fetch("php/send_message.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from, to, message })
    }).then(() => {
        alert("Zpráva odeslána.");
        location.reload();
    });
}