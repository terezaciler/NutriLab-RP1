<?php
header("Content-Type: application/json");

// Získání dat z požadavku
$data = json_decode(file_get_contents("php://input"), true);

// Nová zpráva
$message = [
    "from" => $data["from"],
    "to" => $data["to"],
    "message" => $data["message"],
    "timestamp" => date("c")
];

// Cesta k souboru se zprávami
$file = "../data/messages.json";

// Načíst existující zprávy (pokud existují)
$messages = [];

if (file_exists($file)) {
    $messages = json_decode(file_get_contents($file), true);
}

// Přidat novou zprávu
$messages[] = $message;

// Uložit zpět do JSON souboru
file_put_contents($file, json_encode($messages, JSON_PRETTY_PRINT));

// Odpověď
echo json_encode(["success" => true]);
