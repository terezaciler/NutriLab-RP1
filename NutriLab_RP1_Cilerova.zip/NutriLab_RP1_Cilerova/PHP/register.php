<?php
header("Content-Type: application/json");
$data = json_decode(file_get_contents("php://input"), true);

$name = $data["name"];
$email = $data["email"];
$password = $data["password"];
$role = $data["role"];

$usersFile = "../data/users.json";
$users = json_decode(file_get_contents($usersFile), true);

// Kontrola duplicitního e-mailu
foreach ($users as $user) {
    if ($user["email"] === $email) {
        echo json_encode(["success" => false, "message" => "E-mail už existuje."]);
        exit;
    }
}

// Nové ID
$newId = !empty($users) ? end($users)["id"] + 1 : 1;

// Nový uživatel
$newUser = [
    "id" => $newId,
    "name" => $name,
    "email" => $email,
    "password" => $password,
    "role" => $role
];

// Pokud se jedná o klienta, přidáme další data
if ($role === "klient") {
    $newUser["assignedTo"] = $data["assignedTo"];
    $newUser["program"] = $data["program"];
    $newUser["plan"] = $data["plan"];
}

// Přidání uživatele
$users[] = $newUser;
file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

echo json_encode(["success" => true]);