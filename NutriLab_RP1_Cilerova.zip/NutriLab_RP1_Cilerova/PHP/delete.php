<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$userId = $data["id"];

$usersFile = "../data/users.json";
$users = json_decode(file_get_contents($usersFile), true);

$newUsers = array_filter($users, function ($user) use ($userId) {
    return $user["id"] != $userId;
});

file_put_contents($usersFile, json_encode(array_values($newUsers), JSON_PRETTY_PRINT));
echo json_encode(["success" => true]);
