<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$userId = $data["id"];
$newName = $data["name"];
$newRole = $data["role"];

$usersFile = "../data/users.json";
$users = json_decode(file_get_contents($usersFile), true);

foreach ($users as &$user) {
    if ($user["id"] == $userId) {
        $user["name"] = $newName;
        $user["role"] = $newRole;
    }
}

file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
echo json_encode(["success" => true]);
